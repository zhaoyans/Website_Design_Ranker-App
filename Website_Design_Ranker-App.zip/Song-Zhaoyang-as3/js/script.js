$(document).ready(function(){ // begin document.ready block

	var list = ["Salmon","Tomato","Orange","Lemonchiffon","Papayawhip", 
				"Peachpuff","Cornsilk","Blanchedalmond","Bisque",
 				"Wheat","Chocolate","Olive","Lime","Cornflowerblue",
 				"Lavender","Plum","Honeydew","Mintcream"];

	var leng = list.length;

// write a loop
	for (var i = 0; i < leng; i++){

		$(".leftside").append('<div class="leftitem" style = "background-color:' + list[i] + '">' + list[i] + '</div>');

	}

	$('.leftside').sortable();



	var previouslist = {};

	for (var i=0; i<list.length; i++) {
		previouslist[list[i]] = i;
	}


	$(".clicker").click(function(){

		$('.rightside').html('');
		$('.rightside').html('<h3>Your results:</h3>');
		

		var secondlist = [];
		$(".leftitem").each(function(i){
			secondlist[i] = $(this).text();

		// console.log(i);

		});

		// console.log(secondlist);

// #declare the length again
		var secondleng = secondlist.length;

		// for (var i = 0; i<secondleng; i++){
		// 	$(".rightside").append('<div class = "rightitem"><img src="img/' + secondlist[i] + '.jpg"></div>')
		// }
		// console.log(previouslist);

		for (var i = 0; i<secondleng; i++) {
			$('.rightside').append(
				'<div class="leftitem" style = "background-color:' + list[i] + '">' 
				+'<img src="img/' + secondlist[i] + '.jpg">'
				+'<h4>' + secondlist[i] + '</h4>' 
				+'<span>Ranked: '+ (i+1)+'</span>' 
				+'<br>'
				+'<span>Previously: ' + (previouslist[secondlist[i]]+1) + '</span>' 
				+ '</div>');
		}

		for (var i=0; i<secondlist.length; i++) {
			previouslist[secondlist[i]] = i;
		}





	});
// make loop sortbale





}); //end document.ready block